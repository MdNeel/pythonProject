# Class Project 3: Library Management System
# Project by: Md Mozammel Haq Neel

import add_books
import view_all_books

all_books = []
manu=True
while manu:
    print("Welcome to Library Management System")
    print("0. Enter Zero to Exit the Program")
    print("1. Enter 1 to Add Books in the Management System")
    print("2. Enter 2 to View All Books in the Management System")
    print("----------------------------------------------------------")

    menu = input("Please Select Your Choice From Task Manu: ")

    if menu == "0":
        print("Thanks for using Library Management System ")
        break
    elif menu == "1":
        all_books = add_books.add_books(all_books)
    elif menu == "2":
        view_all_books.view_all_books(all_books)
    else:
        print("You have entered an invalid number, Please Choose a valid number")