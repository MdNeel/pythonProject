from save_all_books import save_all_books


def add_books(all_books):
    book_title = input("Please Enter Book's Title: ")
    book_author = input("Please Enter the Book's Author Name: ")
    book_isbn = int(input("Please Enter the Book's ISBN Number: "))
    publication_year = int(input("Please Enter the Book's Publishing Year Number: "))
    book_price = int(input("Please Enter the Book's Price: "))
    book_quantity = int(input("Please Enter the Book's Quantity Number: "))

    book = {
        "title": book_title,
        "author": book_author,
        "isbn": book_isbn,
        "year": publication_year,
        "price": book_price,
        "quantity": book_quantity,
    }

    all_books.append(book)
    save_all_books(all_books)

    print("Books have been Added Successfully")

    return all_books
