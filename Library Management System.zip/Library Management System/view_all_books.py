def view_all_books(all_books):
    if not all_books :
        print("No book was found in the program")
        return
    for book in all_books:
        details=[f"Title: {book.get('title')},"
                 f"Author: {book.get('author')}",
                 f"ISBN: {book.get('isbn')}",
                 f"Year: {book.get('year')} ",
                 f"Price: {book.get('price')}",
                 f"Quantity: {book.get('quantity')}",
                ]
        print("|".join(details))

    print("-------------------------------------------------------")