import csv
def save_all_books(all_books):
    with open("all_books.csv", mode="w", newline="") as file:
        writer=csv.writer(file)
        writer.writerow(["Title","Author","ISBN","Year","Price","Quantity"])
        for book in all_books:
            writer.writerow([
                book.get("Title",""),
                book.get("Author", ""),
                book.get("ISBN", ""),
                book.get("Year", ""),
                book.get("Price", ""),
                book.get("Quantity", ""),
            ])
