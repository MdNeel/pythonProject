INSERT INTO Doctors (DoctorID, Name, Specialization, Phone)
VALUES 
(1, 'Dr. John Smith', 'Cardiology', '1234567890'),
(2, 'Dr. Jane Doe', 'Neurology', '9876543210'),
(3, 'Dr. Emily Brown', 'Orthopedics', '4561237890'),
(4, 'Dr. Michael Johnson', 'Dermatology', '3216549870'),
(5, 'Dr. Sarah Davis', 'Pediatrics', '6547891230');



INSERT INTO Patients (PatientID, Name, Age, Gender, Phone)
VALUES 
(1, 'Alice Johnson', 25, 'Female', '1112223333'),
(2, 'Bob Smith', 40, 'Male', '2223334444'),
(3, 'Cathy Brown', 30, 'Female', '3334445555'),
(4, 'David Wilson', 50, 'Male', '4445556666'),
(5, 'Eva Davis', 35, 'Female', '5556667777');

INSERT INTO Departments (DepartmentID, Name, Location)
VALUES 
(1, 'Cardiology', 'Building A'),
(2, 'Neurology', 'Building B'),
(3, 'Orthopedics', 'Building C'),
(4, 'Dermatology', 'Building D'),
(5, 'Pediatrics', 'Building E');


INSERT INTO Appointments (AppointmentID, PatientID, DoctorID, Date, Time, Status)
VALUES 
(1, 1, 1, '2024-12-22', '10:00:00', 'Confirmed'),
(2, 2, 2, '2024-12-23', '11:00:00', 'Pending'),
(3, 3, 3, '2024-12-24', '12:00:00', 'Cancelled'),
(4, 4, 4, '2024-12-25', '14:00:00', 'Confirmed'),
(5, 5, 5, '2024-12-26', '16:00:00', 'Pending');

