USE Hospital_Database;
CREATE TABLE Doctors (
    DoctorID INT PRIMARY KEY NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Specialization VARCHAR(100),
    Phone VARCHAR(15)
);

CREATE TABLE Patients (
    PatientID INT PRIMARY KEY NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Age INT,
    Gender VARCHAR(10),
    Phone VARCHAR(15)
);

CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Location VARCHAR(100)
);

CREATE TABLE Appointments (
    AppointmentID INT PRIMARY KEY NOT NULL,
    PatientID INT NOT NULL,
    DoctorID INT NOT NULL,
    Date DATE NOT NULL,
    Time TIME NOT NULL,
    Status VARCHAR(50),

    -- Defining Foreign Key Relationships
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE,
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID) ON DELETE CASCADE
);


