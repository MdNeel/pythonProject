
SELECT * FROM Doctors;
SELECT * FROM Patients;
SELECT * FROM Departments;
SELECT * FROM Appointments;
