from datetime import datetime, timedelta
from file_utils import load_data, save_data

BOOKS_FILE = "data/books.json"
LENDERS_FILE = "data/lenders.json"


def lend_book():
    books = load_data(BOOKS_FILE)
    lenders = load_data(LENDERS_FILE)

    title = input("Enter the book title to lend: ").strip().lower()

    for book in books:
        if book["title"].strip().lower() == title:
            if book["quantity"] > 0:
                while True:
                    try:
                        quantity_to_lend = int(input(f"How many copies of '{book['title']}' would you like to lend? "))
                        if quantity_to_lend <= 0 or quantity_to_lend > book["quantity"]:
                            raise ValueError
                        break
                    except ValueError:
                        print(f"Please enter a valid number between 1 and {book['quantity']}.")

                name = input("Enter borrower name: ").strip()
                phone = input("Enter borrower phone number: ").strip()
                due_date = (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d')

                lenders.append({
                    "name": name,
                    "phone": phone,
                    "book_title": book["title"],
                    "quantity_lent": quantity_to_lend,
                    "due_date": due_date
                })

                # Decrease the quantity
                book["quantity"] -= quantity_to_lend

                # Save the updated data
                save_data(BOOKS_FILE, books)
                save_data(LENDERS_FILE, lenders)

                print(f"{quantity_to_lend} copies of '{book['title']}' lent to {name} until {due_date}.")
                return
            else:
                print(f"No available copies of '{book['title']}' to lend.")
                return

    print(f"Book '{title}' not found in the system.")
