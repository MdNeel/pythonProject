from file_utils import load_data, save_data

BOOKS_FILE = "data/books.json"


def update_book():
    books = load_data(BOOKS_FILE)
    title = input("Enter the book title to update: ")
    for book in books:
        if book["title"].lower() == title.lower():
            print(f"Updating book: {book}")
            book["author"] = input("Enter new author (leave blank to keep current): ") or book["author"]
            book["publishing_year"] = input("Enter new publishing year (leave blank to keep current): ") or book[
                "publishing_year"]
            while True:
                try:
                    price = input("Enter new price (leave blank to keep current): ")
                    book["price"] = float(price) if price else book["price"]
                    break
                except ValueError:
                    print("Invalid price. Please enter a valid number.")
            while True:
                try:
                    quantity = input("Enter new quantity (leave blank to keep current): ")
                    book["quantity"] = int(quantity) if quantity else book["quantity"]
                    break
                except ValueError:
                    print("Invalid quantity. Please enter a valid number.")

            save_data(BOOKS_FILE, books)
            print(f"Book '{title}' updated successfully.")
            return
    print("Book not found.")
