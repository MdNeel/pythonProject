import json
import os

def load_data(file):
    """Load data from a JSON file."""
    if not os.path.exists(file):
        # Ensure file exists by initializing with an empty array
        os.makedirs(os.path.dirname(file), exist_ok=True)
        with open(file, 'w') as f:
            json.dump([], f)
    with open(file, 'r') as f:
        return json.load(f)

def save_data(file, data):
    """Save data to a JSON file."""
    os.makedirs(os.path.dirname(file), exist_ok=True)
    with open(file, 'w') as f:
        json.dump(data, f, indent=4)
