import random
from file_utils import load_data, save_data

BOOKS_FILE = "data/books.json"

def add_book():
    books = load_data(BOOKS_FILE)
    title = input("Enter book title: ")
    author = input("Enter author name: ")
    publishing_year = input("Enter publishing year: ")
    while True:
        try:
            price = float(input("Enter book price: "))
            if price <= 0:
                raise ValueError
            break
        except ValueError:
            print("Price must be greater than zero.")
    while True:
        try:
            quantity = int(input("Enter book quantity: "))
            if quantity <= 0:
                raise ValueError
            break
        except ValueError:
            print("Quantity must be greater than zero.")
    isbn = str(random.randint(100000, 999999))
    book = {"title": title, "author": author, "ISBN": isbn, "publishing_year": publishing_year, "price": price, "quantity": quantity}
    books.append(book)
    save_data(BOOKS_FILE, books)
    print(f"Book added successfully with ISBN: {isbn}")
