from file_utils import load_data, save_data

BOOKS_FILE = "data/books.json"


def delete_book():
    books = load_data(BOOKS_FILE)
    title = input("Enter the book title to delete: ").strip().lower()

    # Iterate through books to find a match
    for book in books:
        if book["title"].strip().lower() == title:
            books.remove(book)  # Remove the book
            save_data(BOOKS_FILE, books)
            print(f"Book '{book['title']}' has been deleted successfully.")
            return

    # If no match is found
    print(f"Book '{title}' not found in the system.")
