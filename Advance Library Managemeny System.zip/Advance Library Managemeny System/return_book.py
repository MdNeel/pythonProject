from file_utils import load_data, save_data

BOOKS_FILE = "data/books.json"
LENDERS_FILE = "data/lenders.json"


def return_book():
    books = load_data(BOOKS_FILE)
    lenders = load_data(LENDERS_FILE)

    title = input("Enter the book title to return: ").strip().lower()
    name = input("Enter borrower name: ").strip()

    for lender in lenders:
        if lender["book_title"].strip().lower() == title and lender["name"].strip().lower() == name.lower():
            for book in books:
                if book["title"].strip().lower() == title:
                    book["quantity"] += lender["quantity_lent"]  # Increase the quantity

            # Remove the lender's record
            lenders.remove(lender)

            # Save the updated data
            save_data(BOOKS_FILE, books)
            save_data(LENDERS_FILE, lenders)

            print(f"The book '{lender['book_title']}' has been returned by {name}.")
            return

    print(f"No record found for '{title}' lent to {name}.")
