"""Project : Advance Library or Book Management System
   Project by : Md Mozammel Haq Neel
"""

from add_book import add_book
from view_books import view_books
from lend_book import lend_book
from return_book import return_book
from update_book import update_book
from delete_book import delete_book

def main():
    while True:
        print("\n Welcome to Library Management System")
        print("1. Add book")
        print("2. View books")
        print("3. Lend book")
        print("4. Return book")
        print("5. Update book")
        print("6. Delete book")
        print("0. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            add_book()
        elif choice == "2":
            view_books()
        elif choice == "3":
            lend_book()
            view_books()  # Display updated books
        elif choice == "4":
            return_book()
            view_books()  # Display updated books
        elif choice == "5":
            update_book()
        elif choice == "6":
            delete_book()
        elif choice == "0":
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
