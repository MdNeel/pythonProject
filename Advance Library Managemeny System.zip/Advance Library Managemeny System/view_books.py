from file_utils import load_data

BOOKS_FILE = "data/books.json"
LENDERS_FILE = "data/lenders.json"

# Utility to truncate text for better fit
def truncate(text, length=15):
    """Truncate text to fit within the table cell."""
    return text if len(text) <= length else text[:length - 3] + "..."

# Utility to format a row
def format_row(columns, widths):
    """Format a row with fixed column widths."""
    return "| " + " | ".join(f"{str(col)[:width]:<{width}}" for col, width in zip(columns, widths)) + " |"

def view_books():
    books = load_data(BOOKS_FILE)
    lenders = load_data(LENDERS_FILE)

    # Column headers and widths for books
    book_headers = ["Title", "Author", "ISBN", "Year", "Price", "Quantity"]
    book_widths = [20, 15, 10, 6, 8, 8]

    # Display books
    if books:
        print("\nBooks in the system:")
        print(format_row(book_headers, book_widths))
        print("-" * (sum(book_widths) + len(book_widths) * 3 + 1))  # Divider
        for book in books:
            print(format_row(
                [
                    truncate(book["title"], book_widths[0]),
                    truncate(book["author"], book_widths[1]),
                    book["ISBN"],
                    book["publishing_year"],
                    f"${book['price']:.2f}",
                    book["quantity"]
                ],
                book_widths
            ))
    else:
        print("\nNo books available in the system.")

    # Column headers and widths for lenders
    lender_headers = ["Borrower", "Phone", "Book Title", "Quantity Lent", "Due Date"]
    lender_widths = [15, 12, 20, 14, 12]

    # Display lenders
    if lenders:
        print("\nBooks lent out:")
        print(format_row(lender_headers, lender_widths))
        print("-" * (sum(lender_widths) + len(lender_widths) * 3 + 1))  # Divider
        for lender in lenders:
            print(format_row(
                [
                    truncate(lender["name"], lender_widths[0]),
                    lender["phone"],
                    truncate(lender["book_title"], lender_widths[2]),
                    lender.get("quantity_lent", 1),
                    lender["due_date"]
                ],
                lender_widths
            ))
    else:
        print("\nNo books are currently lent out.")
